import React, { useState, useEffect } from 'react';
import { useAuth } from '../../contexts/AuthContext';
import { User } from 'firebase/auth';
import axios from 'axios';
import { firestore } from '../../firebaseConfig';
import {
  collection,
  query,
  where,
  getDocs,
  Timestamp,
  DocumentData,
} from 'firebase/firestore';
import { useInfiniteQuery } from '@tanstack/react-query';
import { getImageWithSuffix } from '../../utility/GetUseImage';
import MessageRoom from './MessageRoom';
import {
  generateChatRoomId,
  syncChatRooms,
} from '../../services/firestoreChat';

// 型定義
interface MatchedUser {
  matched_uid: string;
  nickname: string;
  bcuid: string;
  profile_images?: string;
}

interface OpenChatRoom {
  id: string;
  members: string[];
  is_closed: boolean;
  updated_at?: { seconds: number };
  unreadCount: number;
  otherUid: string | null;
  userInfo: MatchedUser | null;
}

interface FetchMatchedListResponse {
  status: number;
  success: boolean;
  message: string;
  data: {
    data: MatchedUser[];
    current_page: number;
    last_page: number;
    next_page_url: string | null;
  };
}

interface MessageRoomProps {
  room: OpenChatRoom;
  currentUser: User;
}

const debug = process.env.REACT_APP_DEBUG === 'true';
const apiEndpoint = process.env.REACT_APP_API_ENDPOINT;

const MessageList: React.FC = () => {
  const { currentUser, token } = useAuth();
  const [matchedList, setMatchedList] = useState<MatchedUser[]>([]);
  const [openChatRooms, setOpenChatRooms] = useState<OpenChatRoom[]>([]);

  // マッチしたユーザーリストの取得
  const fetchMatchedList = async ({ pageParam = 1 }) => {
    try {
      const res = await axios.post<FetchMatchedListResponse>(
        `${apiEndpoint}/v1/get/matched_member?page=${pageParam}`,
        {},
        { headers: { Authorization: `Bearer ${token}` } }
      );
      return res.data;
    } catch (error) {
      console.error('[fetchMatchedList] error:', error);
      throw error;
    }
  };

  // React Queryを使用した無限スクロール
  const { data, fetchNextPage, hasNextPage, isLoading } = useInfiniteQuery({
    queryKey: ['matchedMembers', token],
    queryFn: fetchMatchedList,
    initialPageParam: 1, // これを追加
    getNextPageParam: (lastPage: FetchMatchedListResponse) => {
      if (lastPage.data.next_page_url) {
        const match = lastPage.data.next_page_url.match(/page=(\d+)/);
        return match ? Number(match[1]) : undefined;
      }
      return undefined;
    },
    enabled: !!token,
  });

  // マッチリストの更新
  useEffect(() => {
    if (data) {
      const flatList = data.pages.flatMap(
        (page: FetchMatchedListResponse) => page.data.data
      );
      setMatchedList(flatList);
    }
  }, [data]);

  // チャットルームの同期
  useEffect(() => {
    if (!currentUser?.uid || matchedList.length === 0) return;

    syncChatRooms({
      currentUid: currentUser.uid,
      matchedList,
    }).catch((err) => console.error('[syncChatRooms] error:', err));
  }, [currentUser?.uid, matchedList]);

  // オープンなチャットルームの取得と未読カウント
  useEffect(() => {
    if (!currentUser?.uid || matchedList.length === 0) return;

    const matchedMap = new Map(matchedList.map((m) => [m.matched_uid, m]));

    const fetchOpenChatRooms = async () => {
      try {
        const q = query(
          collection(firestore, 'chats'),
          where('members', 'array-contains', currentUser.uid),
          where('is_closed', '==', false)
        );
        const snapshot = await getDocs(q);

        const rooms = await Promise.all(
          snapshot.docs.map(async (d) => {
            const roomData = d.data() as DocumentData;
            const messagesSnapshot = await getDocs(
              collection(d.ref, 'messages')
            );

            const unreadCount = messagesSnapshot.docs.reduce(
              (count, msgDoc) => {
                const msg = msgDoc.data();
                const readBy = msg.read_by || [];
                return !readBy.includes(currentUser.uid) ? count + 1 : count;
              },
              0
            );

            const otherUid = roomData.members.find(
              (uid: string) => uid !== currentUser.uid
            );
            const matchedUser = matchedMap.get(otherUid ?? '') ?? null;

            return {
              id: d.id,
              ...roomData,
              unreadCount,
              otherUid,
              userInfo: matchedUser,
            } as OpenChatRoom;
          })
        );

        // 最新の更新順にソート
        const sortedRooms = rooms.sort((a, b) => {
          const aTime = a.updated_at?.seconds ?? 0;
          const bTime = b.updated_at?.seconds ?? 0;
          return bTime - aTime;
        });

        setOpenChatRooms(sortedRooms);
      } catch (err) {
        console.error('[fetchOpenChatRooms] error:', err);
      }
    };

    fetchOpenChatRooms();
  }, [currentUser?.uid, matchedList]);

  if (isLoading) {
    return (
      <div className="loading-spinner-container">
        <div className="spinner-border" role="status">
          <span className="visually-hidden">Loading...</span>
        </div>
      </div>
    );
  }

  return (
    <div className="chat-rooms-block message-chat">
      <h1 className="mb-4">メッセージ</h1>

      <ul className="chat-rooms">
        {openChatRooms.length > 0 ? (
          openChatRooms.map((room, index) => (
            <li key={room.id} className="chat-room-item mb-3">
              <div className="d-flex justify-content-start">
                <div className="member-avatar-area">
                  <a href={`/member/${room.userInfo?.bcuid ?? ''}`}>
                    <img
                      className="member-avatar"
                      src={
                        room.userInfo?.profile_images
                          ? getImageWithSuffix(
                              room.userInfo.profile_images,
                              '_thumbnail'
                            )
                          : '/assets/dummy/150x150.png'
                      }
                      alt={`${room.userInfo?.nickname ?? ''}のアバター`}
                    />
                  </a>
                </div>
                <div className="user-info">
                  {room.unreadCount > 0 && (
                    <span className="badge bg-primary me-2">
                      {room.unreadCount}
                    </span>
                  )}
                  <span className="nickname">
                    {room.userInfo?.nickname ?? '読み込み中...'}
                  </span>
                  <span className="bcuid">@{room.userInfo?.bcuid ?? ''}</span>
                </div>
              </div>

              {currentUser && (
                <MessageRoom room={room} currentUser={currentUser} />
              )}
            </li>
          ))
        ) : (
          <div className="alert alert-secondary">
            まだメッセージはありません
          </div>
        )}
      </ul>

      {hasNextPage && (
        <div className="text-center mt-4">
          <button
            className="btn btn-outline-primary"
            onClick={() => fetchNextPage()}
          >
            さらに読み込む
          </button>
        </div>
      )}
    </div>
  );
};

export default MessageList;

import React, { useState, useEffect } from 'react';
import { useAuth } from '../../contexts/AuthContext';
import axios from 'axios';
import { firestore } from '../../firebaseConfig';
import { collection, query, where, getDocs } from 'firebase/firestore';
import { useInfiniteQuery } from '@tanstack/react-query';
import { getImageWithSuffix } from '../../utility/GetUseImage';
import MessageRoom from './MessageRoom';
import {
  generateChatRoomId,
  syncChatRooms,
} from '../../services/firestoreChat';
import { MatchedUser, OpenChatRoom } from '../../types/chat';
import { User } from 'firebase/auth';

const debug = process.env.REACT_APP_DEBUG === 'true';
const apiEndpoint = process.env.REACT_APP_API_ENDPOINT;

interface MessageRoomProps {
  room: OpenChatRoom;
  currentUser: User;
}

const MessageRoom: React.FC<MessageRoomProps> = ({
  room,
  currentUser: propCurrentUser,
}) => {
  const { currentUser, token } = useAuth();
  const [matchedList, setMatchedList] = useState<MatchedUser[]>([]);
  const [openChatRooms, setOpenChatRooms] = useState<OpenChatRoom[]>([]);

  const fetchMatchedList = async ({ pageParam = 1 }) => {
    const res = await axios.post(
      `${apiEndpoint}/v1/get/matched_member?page=${pageParam}`,
      {},
      { headers: { Authorization: `Bearer ${token}` } }
    );
    return res.data.data;
  };

  const { data, fetchNextPage, hasNextPage, isLoading } = useInfiniteQuery(
    ['matchedMembers', token],
    fetchMatchedList,
    {
      getNextPageParam: (lastPage) => {
        return lastPage.current_page < lastPage.last_page
          ? lastPage.current_page + 1
          : undefined;
      },
      enabled: !!token,
    }
  );

  useEffect(() => {
    if (data) {
      const flatList = data.pages.flatMap((page) => page.data);
      setMatchedList(flatList);
    }
  }, [data]);

  useEffect(() => {
    if (!currentUser || matchedList.length === 0) return;

    syncChatRooms({
      currentUid: currentUser.uid,
      matchedList,
    }).catch((err) => console.error('[syncChatRooms] error:', err));
  }, [currentUser, matchedList]);

  useEffect(() => {
    if (!currentUser || matchedList.length === 0) return;

    const matchedMap = new Map(matchedList.map((m) => [m.matched_uid, m]));

    const fetchOpenChatRooms = async () => {
      try {
        const q = query(
          collection(firestore, 'chats'),
          where('members', 'array-contains', currentUser.uid),
          where('is_closed', '==', false)
        );
        const snapshot = await getDocs(q);

        const rooms = await Promise.all(
          snapshot.docs.map(async (d) => {
            const roomData = d.data();
            const messagesSnapshot = await getDocs(
              collection(d.ref, 'messages')
            );
            let unreadCount = 0;

            messagesSnapshot.forEach((msgDoc) => {
              const msg = msgDoc.data();
              const readBy = msg.read_by || [];
              if (!readBy.includes(currentUser.uid)) unreadCount++;
            });

            const otherUid = roomData.members.find(
              (uid: string) => uid !== currentUser.uid
            );
            const matchedUser = matchedMap.get(otherUid ?? '') ?? null;

            return {
              id: d.id,
              ...roomData,
              unreadCount,
              otherUid,
              userInfo: matchedUser,
            } as OpenChatRoom;
          })
        );

        rooms.sort((a, b) => {
          const aTime = a.updated_at?.seconds ?? 0;
          const bTime = b.updated_at?.seconds ?? 0;
          return bTime - aTime;
        });

        setOpenChatRooms(rooms);
      } catch (err) {
        console.error('[fetchOpenChatRooms] error:', err);
      }
    };

    fetchOpenChatRooms();
  }, [currentUser, matchedList]);

  return (
    <>
      <h1>Message</h1>
      {isLoading && <p>Loading...</p>}

      <div className="chat-rooms-block message-chat">
        <ul className="chat-rooms">
          {openChatRooms.length > 0 ? (
            openChatRooms.map((room, index) => (
              <li key={room.id} className="mb20">
                <div className="d-flex justify-content-start">
                  <div className="member-avator-area">
                    <a href={`/member/${room.userInfo?.bcuid ?? ''}`}>
                      <img
                        className="member-avator"
                        src={
                          room.userInfo?.profile_images
                            ? `https://firebasestorage.googleapis.com/v0/b/bcmhzt-b25e9.appspot.com/o/${getImageWithSuffix(
                                room.userInfo.profile_images ?? '',
                                '_thumbnail'
                              )}?alt=media`
                            : '/assets/dummy/150x150.png'
                        }
                        alt={`member-avator-${index}`}
                      />
                    </a>
                  </div>
                  <div className="nick-name">
                    {room.unreadCount > 0 && (
                      <span className="badge bg-primary mr10">
                        {room.unreadCount}
                      </span>
                    )}
                    {room.userInfo?.nickname ?? '読み込み中…'}
                    <span className="bcuid">@{room.userInfo?.bcuid ?? ''}</span>
                  </div>
                </div>
                {currentUser && (
                  <MessageRoom room={room} currentUser={propCurrentUser} />
                )}
              </li>
            ))
          ) : (
            <div className="alert alert-secondary mt20" role="alert">
              まだ、メッセージはありません。
            </div>
          )}
        </ul>
      </div>

      {hasNextPage && (
        <div className="text-center mt-4">
          <button
            className="btn btn-outline-primary"
            onClick={() => fetchNextPage()}
          >
            もっと見る
          </button>
        </div>
      )}
    </>
  );
};

export default MessageList;
